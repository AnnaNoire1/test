<?php
session_start();
?>


<header>
<ul class="navbar-nav ms-auto">

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">



  <a class="nav-link active" aria-current="page" href="index.php">ГЛАВНАЯ</a>

  <a class="nav-link active" aria-current="page" href="person.php">ЛИЧНЫЙ КАБИНЕТ</a>

  <a class="nav-link active" aria-current="page" href="zayavka.php">ЗАЯВКА</a>

  <a class="nav-link active" aria-current="page" href="logout.php">ВЫЙТИ</a>


  </div>
</nav>

<?php
$id_user=$_SESSION['id_user'];
$sql="SELECT * FROM users where id_user='$id_user'";
$result=$mysqli->query($sql);
foreach($result as $row){
  echo "<p style='color:black;'>".$row['fio']."</p>";
}


?>





</header>






















