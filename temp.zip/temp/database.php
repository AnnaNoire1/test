<?php
$mysqli = new mysqli("localhost", "root", "", "dostavka");
$mysqli ->set_charset("UTF8");
?>













