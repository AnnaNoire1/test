<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">


  <ul class="navbar-nav ms-auto">

  <a class="nav-link active" aria-current="page" href="index.php">ГЛАВНАЯ</a>

  <a class="nav-link active" aria-current="page" href="login.php">АВТОРИЗАЦИЯ</a>

  <a class="nav-link active" aria-current="page" href="register.php">РЕГИСТРАЦИЯ</a>


  </div>
</nav>
